package com.workout.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import com.workout.service.bean.CategoryBean;
import com.workout.service.bean.WorkoutsBean;

@Mapper
public interface WorkoutMapper {
    public List<WorkoutsBean> getWorkout() throws DataAccessException;
    public List<CategoryBean> getWorkOuts() throws DataAccessException;
	public void addWorkOuts(@Param("category") CategoryBean inCategoryBean) throws DataAccessException;
	public void deleteWorkOuts(@Param("inCategoryId") String inCategoryId) throws DataAccessException;
	public void addWorkOut(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public void addWorkOutDate(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public void updatetCategory(@Param("categoryBean") CategoryBean inCategoryBean) throws DataAccessException;
	public void updateWorkout(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public void updateWorkoutDate(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public void deleteWorkout(@Param("inworkoutId") final String inworkoutId) throws DataAccessException;
	public void addDateTime(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public void endDateTime(@Param("WorkOutBean") final WorkoutsBean inWorkoutsBean) throws DataAccessException;
	public List<WorkoutsBean> getAllTrack() throws DataAccessException;
	public List<WorkoutsBean> searchExistingWorkout() throws DataAccessException;
	public List<WorkoutsBean> getWorkoutForYear();
	public List<WorkoutsBean> getWorkoutForWeek();
	public List<WorkoutsBean> getWorkoutForMonth();
	
}
