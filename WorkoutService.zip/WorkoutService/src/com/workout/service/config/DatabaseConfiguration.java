package com.workout.service.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * @author ARO_developer
 *
 */
@Configuration
public class DatabaseConfiguration {

    public static final String SQL_MAPPER_PACKAGE       	= "com.workout.service.mapper";
    public static final String DB_TYPE_ALIAS_PACKAGE        = "com.workout.service.bean";
    public static final String DB_SQL_SESSION_FACTORY       = "DBSqlSessionFactory";
    public static final Logger itsLogger                    = LoggerFactory.getLogger(DatabaseConfiguration.class);

    public DatabaseConfiguration() {
        //Empty constructor
    }
    

    /**
     * @return
     */
    @Bean(name = "DBDataSource")
    @Primary
    public static DataSource getARODBDataSource() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        //dataSource.setUrl("jdbc:sqlserver://SMSPBDJDLDB01\\INSTANCE2");
        dataSource.setUrl("jdbc:mysql://localhost:3306/workout");
        dataSource.setUsername("root");
        dataSource.setPassword("root1");
        return dataSource;
    }

    /**
     * @return
     */
    @Bean(name = "DBSqlMapper")
    public static MapperScannerConfigurer getARODBSqlMapperConfigurer() {
        final MapperScannerConfigurer configurer = new MapperScannerConfigurer();
        configurer.setBasePackage(SQL_MAPPER_PACKAGE);
        configurer.setSqlSessionFactoryBeanName(DB_SQL_SESSION_FACTORY);
        return configurer;
    }

    

    /**
     * Define sqlSessionFactory for DB
     * @return
     * @throws BusinessException
     * @throws Exception
     */
    @Bean(name = DB_SQL_SESSION_FACTORY)
    @Autowired
    public static SqlSessionFactory getARODBSqlSessionFactory(@Qualifier("DBDataSource") final DataSource inDataSource) throws Exception {
        return createSessionFactory(inDataSource);
    }

   

    /**
     * @param inDataSource
     * @return
     * @throws Exception 
     */
    private static SqlSessionFactory createSessionFactory(final DataSource inDataSource) throws Exception {
        final SqlSessionFactoryBean theSqlSessionFactoryBean = new SqlSessionFactoryBean();
        theSqlSessionFactoryBean.setDataSource(inDataSource);
        theSqlSessionFactoryBean.setTypeAliasesPackage(DB_TYPE_ALIAS_PACKAGE);
        SqlSessionFactory theSqlSessionFactory;
        try {
            theSqlSessionFactory = theSqlSessionFactoryBean.getObject();
        }catch (final Exception e) {
            itsLogger.error("Error in DatabaseConfiguration", e);
            throw new Exception(e.getMessage());
        }
        theSqlSessionFactory.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);
        return theSqlSessionFactory;
    }

}
