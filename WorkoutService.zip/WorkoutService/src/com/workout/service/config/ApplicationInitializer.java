package com.workout.service.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.apache.logging.log4j.core.config.Configurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import com.workout.service.constant.ApplicationConstants;


/**
 * 
 * ApplicationInitializer is used to perform activity during server startup
 */

@Configuration

public class ApplicationInitializer implements WebApplicationInitializer {

    //  private static final String SECURITY_FILTER = "SecurityFilter";
	final Logger itsLogger = LoggerFactory.getLogger(ApplicationInitializer.class);

    /**
     * Read the JVM -D option that represents the environment.
     * 
     * @return Value of the JVM variable or null
     */
    private String getEnvironment() {
        return "DVL";//System.getProperty(ApplicationConstants.APP_DEPLOYMENT_LVL);
    }

    /* (non-Javadoc)
     * @see org.springframework.web.WebApplicationInitializer#onStartup(javax.servlet.ServletContext)
     */
    @Override
    public void onStartup(final ServletContext inContainer) throws ServletException {
        // Initialize Logger
        final String theEnvironment = getEnvironment();
        // Error checking.
        if ( (theEnvironment == null) || (theEnvironment.trim().length() == 0)) {
            try {
                throw new Exception("Environment variable not set....");
            }catch (final Exception e) {
                // TODO Auto-generated catch block
            	//TODO- remove stack trace and add logger
                e.printStackTrace();
            }
        }
        final StringBuilder theLog4j2ConfigFile = new StringBuilder(ApplicationConstants.WEBINF_CNFG).append(theEnvironment.toLowerCase()).append(ApplicationConstants.LOG4J_FILENAME);
        Configurator.initialize(ApplicationConstants.SERVICE_NAME, theLog4j2ConfigFile.toString());
        itsLogger.info("Logger Initialized for workout Application");
        final AnnotationConfigWebApplicationContext theAppContext = new AnnotationConfigWebApplicationContext();
        theAppContext.register(ServiceSpringConfig.class);
        theAppContext.setServletContext(inContainer);
        final ServletRegistration.Dynamic theServletRegistration = inContainer.addServlet(ApplicationConstants.DISPATCHER_NAME, new DispatcherServlet(theAppContext));
        theServletRegistration.setLoadOnStartup(1);
        theServletRegistration.addMapping("/");  
        // inContainer.addFilter(SECURITY_FILTER, new DelegatingFilterProxy(SECURITY_FILTER)).addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "/AROService/services/*");
    }

}
