package com.workout.service.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.workout.service.bean.BaseBean;
import com.workout.service.bean.ResponseWrapperBean;
import com.workout.service.bean.WorkoutsBean;
import com.workout.service.constant.BusinessConstants;
import com.workout.service.exception.BusinessException;
import com.workout.service.manager.WorkoutManager;

@RestController
@RequestMapping("/services/workout")
public class WorkoutService extends BaseService {

	//private boolean STATUS = false;

	@Autowired
	private WorkoutManager itsWorkoutManager;

	@RequestMapping(method = RequestMethod.GET)
	public List<WorkoutsBean> getAllWorkouts() throws BusinessException {
		
		return itsWorkoutManager.getWorkout().stream().distinct()
		 .collect(Collectors.toList());
		//return new ArrayList<>(new HashSet<>(itsWorkoutManager.getWorkout()));
	}

	@RequestMapping(method = RequestMethod.POST)
	public ResponseWrapperBean<BaseBean> addWorkout(@RequestBody final WorkoutsBean inWorkoutsBean)
			throws BusinessException {
		boolean status = itsWorkoutManager.addWorkout(inWorkoutsBean);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_INSERT_WORKOUT);
		} else {
			return getFailureMessage(BusinessConstants.PROP_INFO_INSERT_WORKOUT_FAILURE);
		}

	}

	@RequestMapping(method = RequestMethod.PUT)
	public ResponseWrapperBean<BaseBean> updateWorkout(@RequestBody final WorkoutsBean inWorkoutsBean) {

		boolean status = itsWorkoutManager.updateWorkout(inWorkoutsBean);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_UPDATE_WORKOUT);
		} else {
			return getFailureMessage(BusinessConstants.PROP_INFO_UPDATE_WORKOUT_FAILURE);
		}
	}

	@RequestMapping(value = "workoutId/{inworkoutId}", method = RequestMethod.DELETE)
	public ResponseWrapperBean<BaseBean> deleteWorkout(@PathVariable final String inworkoutId) {

		boolean status = itsWorkoutManager.deleteWorkout(inworkoutId);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_DELETE_WORKOUT);
		} else {
			return getFailureMessage(BusinessConstants.PROP_INFO_DELETE_WORKOUT_FAILURE);
		}
	}
	
	@RequestMapping(value = "workoutDetails/{type}", method = RequestMethod.GET)
	public List<WorkoutsBean> deleteWorworkoutDetailskout(@PathVariable final String type) {
		return itsWorkoutManager.workoutDetails(type);
	}

}
