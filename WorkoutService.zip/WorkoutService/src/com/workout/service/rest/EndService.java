package com.workout.service.rest;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.workout.service.bean.BaseBean;
import com.workout.service.bean.ResponseWrapperBean;
import com.workout.service.bean.WorkoutsBean;
import com.workout.service.constant.BusinessConstants;
import com.workout.service.exception.BusinessException;
import com.workout.service.manager.WorkoutManager;
@RestController
@RequestMapping("/services/end")
public class EndService extends BaseService{
	
	@Autowired
	private WorkoutManager itsWorkoutManager;
	
	@RequestMapping(method = RequestMethod.POST)
	public ResponseWrapperBean<BaseBean> endDateTime(@RequestBody WorkoutsBean inWorkoutsBean) throws BusinessException, ParseException {
		
		boolean status= itsWorkoutManager.endDateTime(inWorkoutsBean);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_INSERT_END_DATETIME);
		} else {
			return getFailureMessage(BusinessConstants.PROP_INFO_INSERT_END_DATETIME_FAILURE);
		}
	}

}
