package com.workout.service.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.workout.service.bean.BaseBean;
import com.workout.service.bean.MessageBean;
import com.workout.service.bean.ResponseWrapperBean;
import com.workout.service.constant.ApplicationConstants;


public abstract class BaseService {

    @Autowired
    protected Environment itsProperties;

    /**
     * Get Failure Message
     * @param inMessageKeys
     * @return
     */
    protected ResponseWrapperBean<BaseBean> getFailureMessage(final String... inMessageKeys) {
        final ResponseWrapperBean<BaseBean> theFailureResponse = new ResponseWrapperBean<BaseBean>();
        theFailureResponse.setStatus(ApplicationConstants.STATUS_FAILURE);
        theFailureResponse.setMessages(getMessageBeans(inMessageKeys));
        return theFailureResponse;
    }

    /*protected ResponseEntity<ResponseWrapperBean> getSuccessMessage(final String inMessageKey) {
        final ResponseWrapperBean theSuccessResponse = new ResponseWrapperBean();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        final MessageBean theServiceMessageBean = new MessageBean();
        if (itsProperties != null) {
            theServiceMessageBean.setMessageID(itsProperties.getProperty(inMessageKey));
            theServiceMessageBean.setMessageType(itsProperties.getProperty(inMessageKey + ApplicationConstants.PROP_TYPE_SUFFIX));
            theServiceMessageBean.setMessageDetail(itsProperties.getProperty(inMessageKey + ApplicationConstants.PROP_DETAILS_SUFFIX));
        }
        theSuccessResponse.setMessages(Arrays.asList(theServiceMessageBean));
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }*/
    protected ResponseWrapperBean<BaseBean> getSuccessMessage(final String inMessageKey) {
        final ResponseWrapperBean<BaseBean> theSuccessResponse = new ResponseWrapperBean<>();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        final MessageBean theServiceMessageBean = new MessageBean();
        if (itsProperties != null) {
            theServiceMessageBean.setMessageID(itsProperties.getProperty(inMessageKey));
            theServiceMessageBean.setMessageType(itsProperties.getProperty(inMessageKey + ApplicationConstants.PROP_TYPE_SUFFIX));
            theServiceMessageBean.setMessageDetail(itsProperties.getProperty(inMessageKey + ApplicationConstants.PROP_DETAILS_SUFFIX));
        }
        theSuccessResponse.setMessages(Arrays.asList(theServiceMessageBean));
        return theSuccessResponse;
    }

    protected ResponseEntity<ResponseWrapperBean> getSuccessMessage(final String inMessageKey, final String... inMsgParam) {
        final ResponseWrapperBean theSuccessResponse = new ResponseWrapperBean();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        final MessageBean theServiceMessageBean = new MessageBean();
        if (itsProperties != null) {
            theServiceMessageBean.setMessageID(itsProperties.getProperty(inMessageKey));
            theServiceMessageBean.setMessageType(itsProperties.getProperty(inMessageKey + ApplicationConstants.PROP_TYPE_SUFFIX));
        }
        theServiceMessageBean.setMessageDetail(getMessageFromResourceBundle(inMessageKey, inMsgParam));
        theSuccessResponse.setMessages(Arrays.asList(theServiceMessageBean));
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }

    protected ResponseEntity<ResponseWrapperBean> getSuccessReponse(final BaseBean inReponse) {
        final ResponseWrapperBean theSuccessResponse = new ResponseWrapperBean();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        theSuccessResponse.setResponse(inReponse);
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }

    protected ResponseEntity<ResponseWrapperBean> getValidationReponse(final BaseBean inReponse) {
        final ResponseWrapperBean theSuccessResponse = new ResponseWrapperBean();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_VALIDATION);
        theSuccessResponse.setResponse(inReponse);
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }

    /**
     * Get Failure Response and Messages
     * @param inReponse
     * @param inMessageKeys
     * @return
     */

    /**
     * Get Success Response and Messages
     * @param inReponse
     * @param inMessageKeys
     * @return
     */
    protected ResponseEntity<ResponseWrapperBean> getSuccessReponse(final BaseBean inReponse, final String... inMessageKeys) {
        final ResponseWrapperBean<BaseBean> theSuccessResponse = new ResponseWrapperBean<>();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        theSuccessResponse.setResponse(inReponse);
        theSuccessResponse.setMessages(getMessageBeans(inMessageKeys));
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }

    /*
     * validation response and message
     */
    protected ResponseEntity<ResponseWrapperBean> getValidateResponse(final BaseBean inReponse, final String... inMessageKeys) {
        final ResponseWrapperBean<BaseBean> theSuccessResponse = new ResponseWrapperBean<>();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_VALIDATION);
        theSuccessResponse.setResponse(inReponse);
        theSuccessResponse.setMessages(getMessageBeans(inMessageKeys));
        return new ResponseEntity<ResponseWrapperBean>(theSuccessResponse, HttpStatus.OK);
    }
    
    protected ResponseWrapperBean<BaseBean> getSuccessStatus() {
        final ResponseWrapperBean<BaseBean> theSuccessResponse = new ResponseWrapperBean<>();
        theSuccessResponse.setStatus(ApplicationConstants.STATUS_SUCCESS);
        return theSuccessResponse;
    }
    
    protected ResponseWrapperBean<BaseBean> getFailureStatus() {
        final ResponseWrapperBean<BaseBean> theResponse = new ResponseWrapperBean<>();
        theResponse.setStatus(ApplicationConstants.STATUS_FAILURE);
        return theResponse;
    }


    /**
     * Prepare Message List
     * @param inMessageKeys
     * @return
     */
    private List<MessageBean> getMessageBeans(final String... inMessageKeys) {
        final List<MessageBean> theMessageBeans = new ArrayList<>();
        MessageBean theServiceMessageBean;
        if ( (inMessageKeys != null) && (inMessageKeys.length > 0) && itsProperties != null) {
            for (final String theMessageKey : inMessageKeys) {
                theServiceMessageBean = new MessageBean();

                theServiceMessageBean.setMessageID(itsProperties.getProperty(theMessageKey));
                theServiceMessageBean.setMessageType(itsProperties.getProperty(theMessageKey + ApplicationConstants.PROP_TYPE_SUFFIX));
                theServiceMessageBean.setMessageDetail(getMessageFromResourceBundle(theMessageKey));
                theMessageBeans.add(theServiceMessageBean);

            }
        }
        return theMessageBeans;
    }

    private String getMessageFromResourceBundle(final String inMessage, final String... inMessageParm) {
        final Locale theLocale = LocaleContextHolder.getLocale();

        return itsProperties.getProperty(inMessage + ApplicationConstants.PROP_DETAILS_SUFFIX);

    }
}