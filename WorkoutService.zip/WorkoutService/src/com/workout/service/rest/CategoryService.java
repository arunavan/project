package com.workout.service.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.workout.service.bean.BaseBean;
import com.workout.service.bean.CategoryBean;
import com.workout.service.bean.ResponseWrapperBean;
import com.workout.service.constant.BusinessConstants;
import com.workout.service.exception.BusinessException;
import com.workout.service.manager.CategoryManager;

@RestController
@RequestMapping("/services/category")
public class CategoryService extends BaseService {

	@Autowired
	CategoryManager itsCategoryManager;

	/**
	 * 
	 * @return
	 * @throws BusinessException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public List<CategoryBean> getCategory() throws BusinessException {
		return itsCategoryManager.getCategory();

	}

	/**
	 * 
	 * @param inCategoryBean
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public ResponseWrapperBean<BaseBean> addCategory(@RequestBody final CategoryBean inCategoryBean) {

		boolean status = itsCategoryManager.addCategory(inCategoryBean);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_INSERT_CATEGORY);
		} else {

			return getFailureMessage(BusinessConstants.PROP_INFO_INSERT_CATEGORY_FAILURE);
		}

	}

	@RequestMapping(method = RequestMethod.PUT)
	@ResponseBody
	public ResponseWrapperBean<BaseBean> updatetCategory(@RequestBody final CategoryBean inCategoryBean) {

		boolean status = itsCategoryManager.updatetCategory(inCategoryBean);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_UPDATE_CATEGORY);
		} else {

			return getFailureMessage(BusinessConstants.PROP_INFO_UPDATE_CATEGORY_FAILURE);
		}
	}

	@RequestMapping(value = "categoryId/{inCategoryId}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseWrapperBean<BaseBean> deletetCategory(@PathVariable final String inCategoryId) {

		boolean status = itsCategoryManager.deleteCategory(inCategoryId);
		if (status == true) {
			return getSuccessMessage(BusinessConstants.PROP_INFO_DELETE_CATEGORY);
		} else {

			return getFailureMessage(BusinessConstants.PROP_INFO_DELETE_CATEGORY_FAILURE);
		}

	}
}
