package com.workout.service.bean;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseBean {
    private int itsRunId;
   
	public int getRunId() {
        return itsRunId;
    }

    public void setRunId(final int inRunId) {
        itsRunId = inRunId;
    }

}
