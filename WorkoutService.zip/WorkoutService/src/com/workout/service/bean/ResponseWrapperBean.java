package com.workout.service.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseWrapperBean<T extends BaseBean> {

    private T                 itsResponse;
    private String            itsStatus;
    private List<MessageBean> itsMessages;

    public T getResponse() {
        return itsResponse;
    }

    public void setResponse(final T inResponse) {
        itsResponse = inResponse;
    }

    public String getStatus() {
        return itsStatus;
    }

    public void setStatus(final String inStatus) {
        itsStatus = inStatus;
    }

    public List<MessageBean> getMessages() {
        return itsMessages;
    }

    public void setMessages(final List<MessageBean> inMessages) {
        itsMessages = inMessages;
    }

}
