package com.workout.service.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.workout.service.bean.WorkoutsBean;
import com.workout.service.constant.BusinessConstants;
import com.workout.service.exception.BusinessException;
import com.workout.service.mapper.WorkoutMapper;

@Repository("workoutDao")
public class WorkoutDao {
	@Autowired
	WorkoutMapper itsWorkoutMapper;

	public List<WorkoutsBean> getWorkout() throws BusinessException {
		try {
			return itsWorkoutMapper.getWorkout();
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}

	}


	public boolean addWorkout(final WorkoutsBean inWorkoutsBean) throws BusinessException {
		boolean status = false;
		try {
			itsWorkoutMapper.addWorkOut(inWorkoutsBean);
			status = true;

		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
		return status;
	}


	

	public void updateWorkout(WorkoutsBean inWorkoutsBean) throws BusinessException {
		try {
			itsWorkoutMapper.updateWorkout(inWorkoutsBean);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}

	public void updateWorkoutDate(WorkoutsBean inWorkoutsBean) throws BusinessException {
		try {
			itsWorkoutMapper.updateWorkoutDate(inWorkoutsBean);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}

	public void deleteWorkout(String inworkoutId) throws BusinessException {
		try {
			itsWorkoutMapper.deleteWorkout(inworkoutId);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}

	}

	public boolean addDateTime(WorkoutsBean inWorkoutsBean) throws BusinessException {
		boolean status = false;
		try {
			itsWorkoutMapper.addDateTime(inWorkoutsBean);
			status = true;
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
		return status;
	}

	public boolean endDateTime(WorkoutsBean inWorkoutsBean) throws BusinessException {
		boolean status = false;
		try {
			itsWorkoutMapper.endDateTime(inWorkoutsBean);
			status = true;
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
		return status;
	}

	public List<WorkoutsBean> getAllTrack() throws BusinessException {
		try {
			return itsWorkoutMapper.getAllTrack();
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}

	}

	public boolean searchExistingWorkout() throws BusinessException {
		boolean status = false;
		List<WorkoutsBean> theWorkoutList = new ArrayList<>();
		try {
			theWorkoutList = itsWorkoutMapper.searchExistingWorkout();
			if (theWorkoutList.isEmpty()) {
				status = true;
			}
			return status;
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}

	}

	

	/**
	 * this method will return the work out history done in pass days/week/month
	 * @param type can be day/week/month
	 * @return List<WorkoutsBean>
	 */
	public List<WorkoutsBean> getWorkoutDetails(String type) {
		if(type.equals("yearWise")){
			return itsWorkoutMapper.getWorkoutForYear();
		}else if(type.equals("weekWise")){
			return itsWorkoutMapper.getWorkoutForWeek();
		}else if(type.equals("monthWise")){
			return itsWorkoutMapper.getWorkoutForMonth();
		}
		return null;
	}

	/*
	 * public void deleteWorkoutDate(String inworkoutId) throws
	 * BusinessException { try {
	 * itsWorkoutMapper.deleteWorkoutDate(inworkoutId); } catch (final
	 * DataAccessException ex) { throw new
	 * BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR); }
	 * 
	 * }
	 */
}
