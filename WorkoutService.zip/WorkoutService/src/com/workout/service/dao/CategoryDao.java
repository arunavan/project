package com.workout.service.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.workout.service.bean.CategoryBean;
import com.workout.service.constant.BusinessConstants;
import com.workout.service.exception.BusinessException;
import com.workout.service.mapper.WorkoutMapper;

@Repository("categoryDao")
public class CategoryDao {
	@Autowired
	WorkoutMapper itsWorkoutMapper;
	
	
	public List<CategoryBean> getCategory() throws BusinessException {
		try {
			return itsWorkoutMapper.getWorkOuts();
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}
	
	public void addCategory(CategoryBean inCategoryBean) throws BusinessException {
		try {
			itsWorkoutMapper.addWorkOuts(inCategoryBean);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}
	
	public void deleteCategory(String inCategoryId) throws BusinessException {
		try {
			itsWorkoutMapper.deleteWorkOuts(inCategoryId);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}
	
	public void updatetCategory(CategoryBean inCategoryBean) throws BusinessException {
		try {
			itsWorkoutMapper.updatetCategory(inCategoryBean);
		} catch (final DataAccessException ex) {
			throw new BusinessException(BusinessConstants.PROP_DATA_ACCESS_ERROR);
		}
	}
}
