package com.workout.service.manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.workout.service.bean.CategoryBean;
import com.workout.service.dao.CategoryDao;
import com.workout.service.exception.BusinessException;

//TODO add java docs and comments
@Service
public class CategoryManager {
	
	 @Autowired
	 private CategoryDao itsCategoryDao;

	public List<CategoryBean> getCategory() throws BusinessException {
        return itsCategoryDao.getCategory();
    }
	
	public boolean addCategory(CategoryBean inCategoryBean) {
		try{
			itsCategoryDao.addCategory(inCategoryBean);
		  return true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	
	public boolean updatetCategory(CategoryBean inCategoryBean) {
		try{
			itsCategoryDao.updatetCategory(inCategoryBean);
		return true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	
	public boolean deleteCategory(String inCategoryId) {
		try{
			itsCategoryDao.deleteCategory(inCategoryId);
		 return true;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
}
