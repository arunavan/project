package com.workout.service.manager;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.workout.service.bean.WorkoutsBean;
import com.workout.service.dao.WorkoutDao;
import com.workout.service.exception.BusinessException;


//TODO add java docs and comments Use Logger
@Service
public class WorkoutManager {
	@Autowired
	WorkoutDao itsWorkoutDao;

	public List<WorkoutsBean> getWorkout() throws BusinessException {
		return itsWorkoutDao.getWorkout();
	}

	public boolean addWorkout(final WorkoutsBean inWorkoutsBean) throws BusinessException {
		//boolean status = false;
		return itsWorkoutDao.addWorkout(inWorkoutsBean);
		/*
		 * WorkoutsBean theWorkoutsBean=new WorkoutsBean();
		 * theWorkoutsBean.setWorkoutId(inWorkoutsBean.getWorkoutId()); boolean
		 * statusForAddDate=itsWorkoutDao.addWorkoutDate(theWorkoutsBean);
		 */
	/*	if (status) {
			status = true;
		}
		return status;*/
	}

	public boolean updateWorkout(WorkoutsBean inWorkoutsBean) {
		try {
			itsWorkoutDao.updateWorkout(inWorkoutsBean);
			itsWorkoutDao.updateWorkoutDate(inWorkoutsBean);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean deleteWorkout(String inworkoutId) {
		try {
			itsWorkoutDao.deleteWorkout(inworkoutId);
			// itsWorkoutDao.deleteWorkoutDate(inworkoutId);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	//TODO changes method name make it meaningful
	public boolean addDateTime(WorkoutsBean inWorkoutsBean) throws BusinessException {
		boolean status = false;
		status = itsWorkoutDao.addDateTime(inWorkoutsBean);
		return status;
	}

	//TODO changes method name make it meaningful
	public boolean endDateTime(WorkoutsBean inWorkoutsBean) throws BusinessException, ParseException {
		boolean status = false;
		/*
		 * Date endDate=new
		 * SimpleDateFormat("yyyy-mm-dd:HH:mm").parse(inWorkoutsBean.getEndDate(
		 * )+inWorkoutsBean.getEndTime()); Date startDate=new
		 * SimpleDateFormat("yyyy-mm-dd:HH:mm").parse(inWorkoutsBean.
		 * getStartDate()+inWorkoutsBean.getStartTime());
		 * 
		 * long diffInMillies = Math.abs(startDate.getTime() -
		 * endDate.getTime()); long diff = TimeUnit.HOURS.convert(diffInMillies,
		 * TimeUnit.MILLISECONDS);
		 * inWorkoutsBean.setDateDiff(String.valueOf(diff));
		 */
		status = itsWorkoutDao.endDateTime(inWorkoutsBean);

		return status;
	}

	//TODO changes method name make it meaningful
	public List<WorkoutsBean> getAllTrack() throws BusinessException {

		return itsWorkoutDao.getAllTrack();

	}

	public boolean searchExistingWorkout() throws BusinessException {
		boolean status = false;
		status = itsWorkoutDao.searchExistingWorkout();
		return status;
	}

	public List<WorkoutsBean> workoutDetails(String type) {
		return itsWorkoutDao.getWorkoutDetails(type);
	}
}
