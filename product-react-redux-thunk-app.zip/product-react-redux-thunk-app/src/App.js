import './App.css';
//import ProductApp from './components/product_app';
import ProductAppFunc from './components/product_app_func';

function App(props) {
  return (
    <div className="App">
      <ProductAppFunc store={props.store} />
    </div>
  );
}

export default App;
